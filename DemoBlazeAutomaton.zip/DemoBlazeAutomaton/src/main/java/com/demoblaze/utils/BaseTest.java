package com.demoblaze.utils;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseTest {
    protected WebDriver driver;
    protected ConfigReader configReader;
    protected DriverFactory driverFactory;

    @BeforeMethod
    public void setUp() {
        configReader = new ConfigReader();
        driverFactory = new DriverFactory();
        driver = driverFactory.initDriver(configReader.getProperty("browser"));
        driver.get(configReader.getProperty("url"));
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
