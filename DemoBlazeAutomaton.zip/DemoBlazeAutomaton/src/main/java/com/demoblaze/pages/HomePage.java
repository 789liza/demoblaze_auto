package com.demoblaze.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
    @FindBy(id = "login2")
    private WebElement loginLink;

    @FindBy(id = "nameofuser")
    private WebElement userNameLabel;

    private WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void clickLogin() {
        loginLink.click();
    }

    public String getLoggedInUser() {
        return userNameLabel.getText();
    }
}
