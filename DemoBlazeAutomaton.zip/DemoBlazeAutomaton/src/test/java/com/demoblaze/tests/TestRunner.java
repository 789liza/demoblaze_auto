// File: src/test/java/com/demoblaze/tests/TestRunner.java
package com.demoblaze.tests;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = "src/test/resources/login.feature",
        glue = "com/demoblaze/tests"
)
public class TestRunner extends AbstractTestNGCucumberTests {
}
