// File: src/test/java/com/demoblaze/tests/LoginTest.java
package com.demoblaze.tests;

import java.time.Duration;

import org.openqa.selenium.By;
import com.demoblaze.pages.LoginPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LoginTest {
    WebDriver driver;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "D:\\eclipse_projects\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://www.demoblaze.com");
    }

    @Test
    public void loginModalTest() {
        // Click on the login link
        WebElement loginLink = driver.findElement(By.id("login2"));
        loginLink.click();

        // Wait for the modal to appear
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement modal = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("logInModal")));

        // Find elements inside the modal and interact with them
        WebElement usernameField = driver.findElement(By.id("loginusername"));
        WebElement passwordField = driver.findElement(By.id("loginpassword"));
        WebElement loginButton = driver.findElement(By.xpath("//button[contains(text(),'Log in')]"));

        // Enter credentials
        usernameField.sendKeys("yourUsername");
        passwordField.sendKeys("yourPassword");

        // Click login button
        loginButton.click();

        // Optionally, add assertions or further interactions after login
    }


    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
